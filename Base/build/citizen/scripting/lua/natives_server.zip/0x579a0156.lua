function Global.GetVehicleHandbrake(vehicle)
	return _in(0x483b013c, vehicle, _r)
end
