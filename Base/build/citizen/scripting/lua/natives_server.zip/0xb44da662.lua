function Global.GetHeliMainRotorHealth(vehicle)
	return _in(0xf01e2aab, vehicle, _rf)
end
