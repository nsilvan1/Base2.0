function Global.GetPlayerMaxHealth(playerSrc)
	return _in(0x8154e470, _ts(playerSrc), _ri)
end
