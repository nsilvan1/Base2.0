function Global.SetPedCanRagdoll(ped, toggle)
	return _in(0xcf1384c4, ped, toggle)
end
