function Global.GetVehicleNumberPlateText(vehicle)
	return _in(0xe8522d58, vehicle, _s)
end
