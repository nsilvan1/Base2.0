function Global.GetPedMaxHealth(ped)
	return _in(0xa45b6c8d, ped, _ri)
end
