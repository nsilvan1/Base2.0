function Global.GetPlayerInvincible(playerSrc)
	return _in(0x680c90ee, _ts(playerSrc), _r)
end
