function Global.GetNumPlayerTokens(playerSrc)
	return _in(0x619e4a3d, _ts(playerSrc), _ri)
end
