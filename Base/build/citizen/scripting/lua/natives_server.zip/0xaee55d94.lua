function Global.GetPlayerName(playerSrc)
	return _in(0x406b4b20, _ts(playerSrc), _s)
end
